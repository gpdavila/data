#!/usr/bin/env python3.4
import csv
last_cell = 0
amostras = 0
pci = 0
mem = 0
cpu0 = 0
cpu1 = 0
gpu = 0
apu = 0

data = [] # Aqui vamos armazenar os dados 
for i in range(1,11):
	with open('bfs%d.csv' %i, 'r') as f:
		with open( "all.csv","a" ) as file_d:
			mycsv = csv.reader(f,delimiter=',')
			for row in mycsv:
				data.append(row)
				last_cell = last_cell +1

			amostras = last_cell - 27 # Os dados começam no 27 	
			for j in range (27,last_cell):
				file_d.write("%f,%f,%f,%f,%f,%f\n" % (float(data[j][2]),float(data[j][3]),float(data[j][4]),float(data[j][6]),float(data[j][7]),float(data[j][8])))
#				print("J:%d "%j)
#				pci = pci + float(data[j][2])
#				mem = mem + float(data[j][3])
#				apu = apu + float(data[j][4])
#				cpu0 = cpu0 + float(data[j][6])
#				cpu1 = cpu1 + float(data[j][7]) 
#				gpu = gpu + float(data[j][8])
	del data[:]	# Elimina os dados da iteração anterior
	last_cell = 0
#	print("%d" %amostras)
