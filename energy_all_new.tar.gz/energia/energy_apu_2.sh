#!/bin/sh

NAME1=$1
NAME2=$2
AMOSTRAGEM=100 # em ms
DURATION=1000 # em segundos
#echo "$NAME1"
#echo "$NAME2"
mkdir /home/carol/energia/$NAME1+CPU
mkdir /home/carol/energia/$NAME1+10
mkdir /home/carol/energia/$NAME1+30
mkdir /home/carol/energia/$NAME1+50
mkdir /home/carol/energia/$NAME1+60
mkdir /home/carol/energia/$NAME1+GPU


for I in 1 2 3 4 5 6 7 8 9 10 
do
#CPU
	/opt/CodeXL_2.5-25/CodeXLPowerProfiler -P power -z /home/carol/energia/$NAME1+CPU/ -o /home/carol/energia/$NAME1+CPU/$NAME2$I  -T $AMOSTRAGEM -d $DURATION /home/carol/Desktop/chai/OpenCL-D/$NAME1/$NAME2 -p 0 -d 0 -i 16 -a 1.00 -t 4 -r 1000 -w 0 -f /home/carol/Desktop/chai/OpenCL-D/CEDD/input/urban_input/ -c /home/carol/Desktop/chai/OpenCL-D/CEDD/output/urban_output/
	sleep 2
#Aqui falta
# 10
	/opt/CodeXL_2.5-25/CodeXLPowerProfiler -P power -z /home/carol/energia/$NAME1+10/ -o /home/carol/energia/$NAME1+10/$NAME2$I  -T $AMOSTRAGEM -d $DURATION /home/carol/Desktop/chai/OpenCL-D/$NAME1/$NAME2 -p 0 -d 0 -i 16 -a 0.90 -t 4 -r 1000 -w 0 -f /home/carol/Desktop/chai/OpenCL-D/CEDD/input/urban_input/ -c /home/carol/Desktop/chai/OpenCL-D/CEDD/output/urban_output/
	sleep 2
# 30
	/opt/CodeXL_2.5-25/CodeXLPowerProfiler -P power -z /home/carol/energia/$NAME1+30/ -o /home/carol/energia/$NAME1+30/$NAME2$I  -T $AMOSTRAGEM -d $DURATION /home/carol/Desktop/chai/OpenCL-D/$NAME1/$NAME2 -p 0 -d 0 -i 16 -a 0.70 -t 4 -r 1000 -w 0 -f /home/carol/Desktop/chai/OpenCL-D/CEDD/input/urban_input/ -c /home/carol/Desktop/chai/OpenCL-D/CEDD/output/urban_output/ 
	sleep 2
# 50
	/opt/CodeXL_2.5-25/CodeXLPowerProfiler -P power -z /home/carol/energia/$NAME1+50/ -o /home/carol/energia/$NAME1+50/$NAME2$I  -T $AMOSTRAGEM -d $DURATION /home/carol/Desktop/chai/OpenCL-D/$NAME1/$NAME2 -p 0 -d 0 -i 16 -a 0.50 -t 4 -r 1000 -w 0 -f /home/carol/Desktop/chai/OpenCL-D/CEDD/input/urban_input/ -c /home/carol/Desktop/chai/OpenCL-D/CEDD/output/urban_output/ 
	sleep 2
#60
	/opt/CodeXL_2.5-25/CodeXLPowerProfiler -P power -z /home/carol/energia/$NAME1+60/ -o /home/carol/energia/$NAME1+60/$NAME2$I  -T $AMOSTRAGEM -d $DURATION /home/carol/Desktop/chai/OpenCL-D/$NAME1/$NAME2 -p 0 -d 0 -i 16 -a 0.40 -t 4 -r 1000 -w 0 -f /home/carol/Desktop/chai/OpenCL-D/CEDD/input/urban_input/ -c /home/carol/Desktop/chai/OpenCL-D/CEDD/output/urban_output/ 
	sleep 2
#DONE
#GPU
	/opt/CodeXL_2.5-25/CodeXLPowerProfiler -P power -z /home/carol/energia/$NAME1+GPU/ -o /home/carol/energia/$NAME1+GPU/$NAME2$I  -T $AMOSTRAGEM -d $DURATION /home/carol/Desktop/chai/OpenCL-D/$NAME1/$NAME2 -p 0 -d 0 -i 16 -a 0.00 -t 1 -r 1000 -w 0 -f /home/carol/Desktop/chai/OpenCL-D/CEDD/input/urban_input/ -c /home/carol/Desktop/chai/OpenCL-D/CEDD/output/urban_output/ 
	sleep 2
done
