#!/bin/sh

NAME1=$1
NAME2=$2
AMOSTRAGEM=100 # em ms
DURATION=1000 # em segundos
#echo "$NAME1"
#echo "$NAME2"
mkdir /home/carol/energia/$NAME1+CPU
mkdir /home/carol/energia/$NAME1+30
#mkdir /home/carol/energia/$NAME1+50
#mkdir /home/carol/energia/$NAME1+60
mkdir /home/carol/energia/$NAME1+GPU


for I in 1 2 3 4 5 6 7 8 9 10 
do
#CPU
	/opt/CodeXL_2.5-25/CodeXLPowerProfiler -P power -z /home/carol/energia/$NAME1+CPU/ -o /home/carol/energia/$NAME1+CPU/$NAME2$I  -T $AMOSTRAGEM -d $DURATION /home/carol/Desktop/chai/OpenCL-D/$NAME1/$NAME2 -p 0 -d 0 -i 8 -g 256  -t 2 -f input/colorado_graph_in -c output/colorado_graph_out  -r 1 -l 90000000
	sleep 2
# 30
	/opt/CodeXL_2.5-25/CodeXLPowerProfiler -P power -z /home/carol/energia/$NAME1+30/ -o /home/carol/energia/$NAME1+30/$NAME2$I  -T $AMOSTRAGEM -d $DURATION /home/carol/Desktop/chai/OpenCL-D/$NAME1/$NAME2 -p 0 -d 0 -i 8 -g 256  -t 2 -f input/colorado_graph_in -c output/colorado_graph_out  -r 1 -l 128
	sleep 2
#DONE
#GPU
	/opt/CodeXL_2.5-25/CodeXLPowerProfiler -P power -z /home/carol/energia/$NAME1+GPU/ -o /home/carol/energia/$NAME1+GPU/$NAME2$I  -T $AMOSTRAGEM -d $DURATION /home/carol/Desktop/chai/OpenCL-D/$NAME1/$NAME2 -p 0 -d 0 -i 8 -g 256  -t 2 -f input/colorado_graph_in -c output/colorado_graph_out  -r 1 -l 0
	sleep 2
done
